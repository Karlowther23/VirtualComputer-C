#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char instrcSet();

int compareFlag = 0;
int dataMemory[100];
int r1, r2, r3, r4, r5, r6, r7, r8, r9, r10;
char codeMemory [100][50];
int tempConstant;


char move(int *param1, int *param2) {
  *param1=*param2;
}

char store(int *reg, int *constant) {
  dataMemory[*reg] = *constant;
}

char load(int *param1, int *param2) {
  printf("%d %d\n", *param1, *param2);
   *param1 = dataMemory[*param2];
}

char input(int *param1) {
  printf("Type in value: ");
  int num;
  scanf("%d", &num);
  dataMemory[*param1] = num;
}

char output(int *param1) {
  printf("%d\n",*param1);
}

void add(int *reg, int *constant) {
  *reg+=*constant;
}

char xor(int *param1, int *param2) {
  *param1 ^= *param2;
}

char test(int *param1, int *param2) {
  if(*param1 == *param2){
    compareFlag = 1;
  }
  else {
    compareFlag = 0;
  }
}

int jumpeq(int address, int pc) {
    if(compareFlag == 1){
        compareFlag = 0;
        return address;
    }
    return pc;
}

int jumpneq(int address, int pc) {
    if(compareFlag == 0){
        compareFlag = 0;
        return address;
    }
    return pc;
}

int jump(int address) {
    compareFlag = 0;
    return address;
}

char ext(){
  exit(0);
}

int* getReg(char *reg) {
  reg[strcspn(reg, ",")] = 0;
  reg[strcspn(reg, "\n")] = 0;
  if(strcmp(reg, "R1") == 0)      { return &r1; }
  else if(strcmp(reg, "R2") == 0) { return &r2; }
  else if(strcmp(reg, "R3") == 0) { return &r3; }
  else if(strcmp(reg, "R4") == 0) { return &r4; }
  else if(strcmp(reg, "R5") == 0) { return &r5; }
  else if(strcmp(reg, "R6") == 0) { return &r6; }
  else if(strcmp(reg, "R7") == 0) { return &r7; }
  else if(strcmp(reg, "R8") == 0) { return &r8; }
  else if(strcmp(reg, "R9") == 0) { return &r9; }
  else if(strcmp(reg, "R10") == 0){ return &r10; }
  else {
    tempConstant = atoi(reg);
    return &tempConstant;
  }
}

char instrcSet(){
  int pc = 0; //program counter
  char delim[] = " ";
  char instruction[50];
  int *param1, *param2;

  while(1) {
    strcpy(instruction, codeMemory[pc++]);
    instruction[strcspn(instruction, "\n")] = 0;
    char *ptr = strtok(instruction, delim); //instruction is the line, ptr is the word
    printf("%d: %s",pc-1, codeMemory[pc-1]);
    while (ptr != NULL) {
      if(strcmp(ptr, "MOVE") == 0)        {
        ptr = strtok(NULL, delim);
        param1 = getReg(ptr);  //stepping through instrc and getting registers, currently strings but need to ref variables
        ptr = strtok(NULL, delim);
        param2 = getReg(ptr);
        move(param1, param2);
      }

      else if(strcmp(ptr, "STORE") == 0)  {
        ptr = strtok(NULL, delim);
        param1 = getReg(ptr);  //stepping through instrc and getting registers, currently strings but need to ref variables
        ptr = strtok(NULL, delim);
        param2 = getReg(ptr);
        store(param1, param2);
      }

      else if(strcmp(ptr, "LOAD") == 0)   {
        ptr = strtok(NULL, delim);
        param1 = getReg(ptr);  //stepping through instrc and getting registers, currently strings but need to ref variables
        ptr = strtok(NULL, delim);
        param2 = getReg(ptr);
        load(param1, param2);
      }

      else if(strcmp(ptr, "INPUT") == 0)  {
        ptr = strtok(NULL, delim);
        param1 = getReg(ptr);
        input(param1);
      }
      else if(strcmp(ptr, "OUTPUT") == 0) {
        ptr = strtok(NULL, delim);
        param1 = getReg(ptr);
        output(param1);
      }
      else if(strcmp(ptr, "ADD") == 0)    {
        ptr = strtok(NULL, delim);
        param1 = getReg(ptr);  //stepping through instrc and getting registers, currently strings but need to ref variables
        ptr = strtok(NULL, delim);
        param2 = getReg(ptr);
        add(param1, param2);
      }
      else if(strcmp(ptr, "XOR") == 0)    {
        ptr = strtok(NULL, delim);
        param1 = getReg(ptr);  //stepping through instrc and getting registers, currently strings but need to ref variables
        ptr = strtok(NULL, delim);
        param2 = getReg(ptr);
        xor(param1, param2);
      }
      else if(strcmp(ptr, "TEST") == 0)   {
        ptr = strtok(NULL, delim);
        param1 = getReg(ptr);  //stepping through instrc and getting registers, currently strings but need to ref variables
        ptr = strtok(NULL, delim);
        param2 = getReg(ptr);
        test(param1, param2);
      }

      else if(strcmp(ptr, "JUMPEQ") == 0)   {
        ptr = strtok(NULL, delim);
        pc = jumpeq(atoi(ptr), pc);
      }

      else if(strcmp(ptr, "JUMPNEQ") == 0)   {
        ptr = strtok(NULL, delim);
        pc = jumpneq(atoi(ptr), pc);
      }

      else if(strcmp(ptr, "JUMP") == 0)   {
        ptr = strtok(NULL, delim);
        pc = jump(atoi(ptr));
      }

      else if(strcmp(ptr, "EXIT") == 0)   {
        ext();
      }
      ptr = strtok(NULL, delim);
    }
  }
}


char *execute(char *filename) {
  FILE *fp;
  char *instruction;                                          // Buffer which holds current instruction
  size_t len = 0;                                             // Pointer to size of buffer (needed for getline())
  int counter = 0;

  if (!(fp = fopen(filename, "r"))) { return "File not found"; } // If file not found, exit with error

  while ((getline(&instruction, &len, fp)) != EOF) {
    strcpy(codeMemory[counter++], instruction);  //putting the indstruction into the index
  }

  free(instruction);
  fclose(fp);
  instrcSet();

}

int main( int argc, char *argv[] ){

  if( argc == 2 )     { execute(argv[1]); }
  else if( argc > 2 ) { printf("Too many arguments supplied.\n"); }
  else                { printf("One argument expected.\n"); }
}
